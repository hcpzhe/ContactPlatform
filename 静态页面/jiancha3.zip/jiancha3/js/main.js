// JavaScript Document
$(function(){
  $(".left-menu dt").click(function(){
   var _this=$(this); 
   var _dd=$(this).next("dd");
   if(_this.next().is("dd")){
	  if(_this.hasClass("current")){
		  _this.removeClass("current");
		  _dd.hide();   
		  }
	   else{
		   _this.addClass("current").siblings("dt").filter(".current").next("dd").hide();
		   _this.addClass("current").siblings("dt").removeClass("current");		   
		   _this.addClass("current").next("dd").show();		               				
		   }
	   }
   else{
	   return false
	   }
   })
  
  $(".nav li").click(function(){
    $(this).addClass("selected")
	        .siblings("li").removeClass("selected");
  
  })
  
  
  /*�����Ŀ����2*/
  $(".left-menu2 dt").click(function(){
	  if($(this).next().is("dd")){
		  
	    if($(this).hasClass("current")){
		  $(this).removeClass("current");
		  $(this).next("dd").hide();
	    } 
		else{
		   $(this).addClass("current").siblings("dt").filter(".current").next("dd").hide();
		   $(this).addClass("current").siblings("dt").removeClass("current");		   
		   $(this).addClass("current").next("dd").show();		               				
		   }
	}
	else{
	   return false
	   }
	
	})
  
  $(".left-menu2 li").hover(function(){
    $(this).addClass("hover");
  },function(){
	 $(this).removeClass("hover");
	 })
  
  
})